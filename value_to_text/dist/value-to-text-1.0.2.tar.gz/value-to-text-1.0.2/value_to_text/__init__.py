# from value_to_text.write_value import Value_to_text
# value_to_text = Value_to_text()
# num_to_text = value_to_text.num_to_text
# perc_to_text = value_to_text.perc_to_text



